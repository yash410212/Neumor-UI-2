# Build Hardening

This project is prepared for a deterministic GitHub Actions Android build.

## Build assumptions
- Gradle: 8.13
- Android Gradle Plugin: 8.13.0
- Kotlin: 2.2.20
- JDK: 17
- compileSdk: 35
- minSdk: 26

## Reliability changes
- Gradle parallel execution is disabled to reduce CI resource contention.
- Gradle daemon is disabled for CI-style builds.
- Gradle worker count is capped.
- Kotlin incremental compilation is disabled to avoid stale incremental-cache failures in clean CI builds.
- AndroidX/Jetifier configuration is explicit.
- Release minification/resource shrinking remains disabled, keeping the APK build path simple.

Do not add a workflow file inside this ZIP. The GitHub Actions workflow should extract this project and invoke the Gradle 8.13 build with JDK 17.
