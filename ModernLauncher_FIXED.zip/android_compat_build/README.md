# Modern Launcher — Android 8–15 compatibility build

## Compatibility
- Minimum SDK: Android 8.0 / API 26
- Compile SDK: API 35
- Target SDK: API 35 (Android 15)
- Java/Kotlin target: JVM 17
- AndroidX + Jetpack Compose

## Compatibility work
- API 29+ default Home role request is guarded; Android 8–9 falls back to Home Settings.
- AppWidget APIs are used through AndroidX/standard platform APIs available from API 26.
- Android 15 edge-to-edge is enabled through `enableEdgeToEdge()` while keeping the minimum SDK at API 26.
- Launcher activity is exported with both LAUNCHER and HOME/DEFAULT intent filters.
- State is stored in SharedPreferences so settings/home ordering/current page survive process death and reboot.
- Configuration/rotation is allowed (`screenOrientation=unspecified`, resizeable activity).
- Package queries are declared for launcher app discovery and widgets.

## Build
Open in Android Studio with Android SDK Platform 35 installed, sync Gradle, then build `app` debug/release.

The environment used to prepare this archive does not contain the Android SDK/Gradle distribution, so an APK could not be compiled or device-tested here. The Gradle wrapper properties/scripts are included; the wrapper JAR must be generated/downloaded by Gradle/Android Studio if it is not already present.

## Performance modes
- **High Performance** is the default. It keeps the full visual/animation profile, composes one adjacent home page for smoother paging, and keeps higher-resolution icon bitmaps.
- **Lite Performance** is optional. It reduces background/page composition and icon bitmap memory usage to lower rendering and RAM pressure.
- Lite mode does **not** automatically reduce the Animation Value, Animation Duration, or Animation Type. The existing Animation Control sliders remain user-controlled.
- No device is forced into Lite mode automatically.

## Final design polish
- Custom wallpaper picker with persistent launcher background.
- Productive Mode and selective Study Mode with dedicated filtered home layout.
- Wallpaper, performance, animation and special-feature settings use the same rounded neumorphic visual language.
- High Performance remains the default; animation defaults remain full quality (70%, 500 ms, Spring).
