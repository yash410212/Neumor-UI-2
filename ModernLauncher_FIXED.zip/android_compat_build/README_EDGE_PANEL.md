# Edge Panel

## Settings
Settings -> Edge Panel provides:
- Enable/disable Edge Panel
- Activation gesture: Left Edge, Right Edge, or Both Edges
- Up to 8 selectable shortcuts
- Built-in shortcuts: Launcher Settings, App Drawer, Wi-Fi Settings, Bluetooth Settings, Battery Settings, Phone/Dialer
- Installed-app shortcuts from the launcher's app list

## Gesture
With Edge Panel enabled, swipe inward from the selected screen edge. The panel opens with a neumorphic slide animation.

## Persistence
Edge Panel enabled state, selected gesture, and shortcut list are saved in SharedPreferences and restored on launcher restart.

## Notes
The panel does not require overlay permission because it is rendered inside the launcher activity/home screen. It is therefore available while the launcher is visible.
