# Heavy Home Animation

Added a clearly visible but controlled home-screen animation mode.

- Heavy Home Animations is enabled by default.
- Home icons continuously float vertically, gently scale, and tilt.
- Each icon receives a staggered phase so the grid does not move as one block.
- Settings: Animation Control -> Heavy Home Animations.
- The setting is persisted in SharedPreferences.
- Battery Saver automatically suppresses heavy motion to reduce rendering load.
- Extreme Performance keeps heavy motion enabled.
- Existing drag/drop long-press behavior remains intact.
