# Interaction Polish

Added home-screen editing interactions:

- Long-press an icon: enters drag mode and shows a Remove action after release.
- Drag an icon after long-press: reorder within the page, create/add to folders, or move across pages.
- Remove an icon: removes it only from the home screen and persists across app refresh/restart.
- Add an icon back: open App Drawer and long-press an app to add it to the home screen.
- Long-press a widget: opens its edit controls while retaining page-drag support.
- Widget resize: W-/W+ and H-/H+ change stored spans and Android widget sizing options.
- Widget replace: opens the system widget picker and preserves the old widget's page and size when the replacement succeeds.
- Widget remove: deletes the home record and releases the Android AppWidgetHost ID.
