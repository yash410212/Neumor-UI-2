# Neumorphic UI Polish

Applied to the launcher home UI:
- Stronger soft raised depth on cards and app icons.
- Crisp top-left specular highlight with restrained bottom-right shading.
- Subtle 1dp light rim to separate surfaces from the background.
- Progress, metrics, calendar, widgets, controls and launcher icons use the same tactile material.
- Kept the existing layout, interactions, wallpaper support and launcher logic intact.
- Settings layout was not redesigned.

Build note: this source package still needs the Gradle wrapper JAR when built with `./gradlew`.
