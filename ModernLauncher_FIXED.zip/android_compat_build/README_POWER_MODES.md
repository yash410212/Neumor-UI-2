# Battery Saver + Extreme Performance

## Battery Saver
Launcher-local power optimization:
- Caps launcher animation intensity at 35%.
- Caps launcher animation duration at 260ms so Saver cannot leave slow, long transitions active.
- Disables launcher background blur effect while active.
- Reduces HorizontalPager off-screen page composition to zero.
- Uses a smaller 56px icon bitmap cache.

## Extreme Performance
Launcher-local responsiveness optimization:
- Forces 100% animation intensity.
- Caps launcher transition duration at 220ms.
- Preloads up to two neighboring home pages.
- Uses a larger 128px icon bitmap cache for sharper/faster repeated icon rendering.
- Clears and rebuilds the icon cache when switching modes.

The profiles are mutually exclusive and persist across restarts.

Important: a normal third-party Android launcher cannot directly change the phone's CPU governor, thermal limits, or OEM system-wide battery-saver state without privileged/system access. These modes therefore optimize the launcher's own workload and rendering behavior.
