# Neumorphic Real Working Widgets

## Settings
Widgets are managed from **Settings → Widgets**. No widget is added automatically just by installing/opening the launcher.

Available launcher widgets:
- Clock: live time/date
- Search: opens web search
- Quick Actions: dialer + email
- Music: reads the active Android media session and sends play/pause/previous/next commands
- Battery: live battery level
- Connectivity: opens Wi‑Fi/Bluetooth settings
- Weather: opens current-weather search
- Android system widgets: native AppWidget picker for installed apps

## Widget editing
Long-press a widget on the home screen to enter widget edit mode. Width/height can be adjusted, the widget can be removed, and it can be replaced with a native Android widget.

## Music controls
The Music Widget uses Android MediaSession APIs. To control YouTube Music or another supported music app, enable **Settings → Widgets → Enable music controls** (Notification access), then start playback in the music app. The widget reads the active media session and sends transport controls to it.

Actual app compatibility depends on whether the music app exposes a controllable MediaSession on the device.
