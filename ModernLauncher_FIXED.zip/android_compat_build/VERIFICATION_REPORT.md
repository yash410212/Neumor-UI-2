# ModernLauncher — Deep Wiring Verification

Date: 2026-09-18

## Verified in source/wiring

- Widget settings entry exists and custom widgets are **not auto-added** on startup.
- Custom widget Add actions persist widget records.
- Native Android widget picker is wired through `AppWidgetHost` / `AppWidgetManager`.
- Native widget IDs are allocated by the host and invalid native IDs are pruned on startup.
- Native widget binding is performed before configuration, matching Android's widget-host flow.
- Native widget removal deallocates the host widget ID.
- Widget Replace preserves the old page/span and replaces the old host record.
- Widget resize persists span X/Y and updates AppWidget options; API 31+ also receives size information through `AppWidgetHostView.updateAppWidgetSize`.
- Widget long-press edit controls expose width/height resize, Replace, Remove, and close.
- Clock, battery, quick actions, connectivity, search, weather shortcut, and music custom widgets are wired.
- Music widget reads active `MediaSession` controllers through the notification-listener service and exposes previous/play-pause/next transport controls.
- Charging notch listens to `ACTION_BATTERY_CHANGED`, shows only while charging/full, displays live percentage, and persists enabled/style/speed settings.
- Battery Saver and Extreme Performance are mutually exclusive and persist their state in SharedPreferences.
- Icon long-press drag/drop and home removal wiring remains connected.
- Neumorphic surfaces were polished with layered shadow, highlight rim, and subtle gradient depth.

## Static validation

- Kotlin source brace balance: PASS.
- Required widget/charging/music/power symbols present: PASS.
- ZIP structure: PASS.

## Build limitation

A complete Android APK build was not executable in this environment because the project ZIP does not contain `gradle-wrapper.jar`. Running `./gradlew` therefore stops before compilation with `Unable to access jarfile .../gradle-wrapper.jar`.

So this report confirms source-level wiring and static integrity, **not device-runtime 100% confirmation**. Final runtime confirmation requires a successful Android build followed by installation/testing on the target phone.

## Edge Panel pass
- Added dedicated Settings -> Edge Panel page.
- Added enable/disable control.
- Added Left Edge / Right Edge / Both Edges activation gesture.
- Added up to 8 selectable shortcuts.
- Added built-in shortcuts and installed-app shortcuts.
- Added slide-in neumorphic Edge Panel overlay.
- Added SharedPreferences persistence for Edge Panel configuration.
- Kotlin source parser check: no syntax/parse diagnostics detected.
- Full Android/Gradle compile was not run because the project wrapper distribution JAR is not present in this environment.


## Build-hardening pass
- Added deterministic CI Gradle settings in `gradle.properties`.
- Kept the last known-good Android/Kotlin/Compose dependency versions unchanged.
- Kept the GitHub Actions workflow outside the ZIP as required.
- Local APK compilation was not claimed because this environment does not have the Gradle 8.13 distribution/wrapper JAR available.
